package de.oszimt.carmanagement;

import java.sql.SQLException;
import java.util.HashMap;

public class Car {
    public int id;
    public String location;
    public String brand;
    public String type;
    public String status;
    int locationId;
    int statusId;
    int brandId;
    int typeId;
    int km;
    double price;

    public Car(int locationId, int brandId, int typeId, int statusId, int km, double price) throws SQLException {
        this.locationId = locationId;
        this.brandId = brandId;
        this.statusId = statusId;
        this.typeId = typeId;
        this.km = km;
        this.price = price;
        getNamesFromDb();
    }

    public Car(HashMap<String, Object> map) throws SQLException {
        id = (int) map.get("id");
        locationId = (int) map.get("location_id");
        brandId = (int) map.get("brand_id");
        typeId = (int) map.get("type_id");
        statusId = (int) map.get("status_id");
        km = (int) map.get("km");
        price = (double) map.get("price");
        getNamesFromDb();
    }

    public void getNamesFromDb() throws SQLException {
        location = Db.getName("location", locationId);
        brand = Db.getName("brand", brandId);
        status = Db.getName("status", statusId);
        type = Db.getName("type", typeId);
    }

    @Override
    public String toString() {
        return String.format("Car\n\n" + "ID: %s\n" + "Brand: %s\n" + "Location: %s\n" + "Status: %s\n" + "Type: %s\n"
                + "Kilometers: %d\n" + "Price: %.2f\n", id, brand, location, status, type, km, price);
    }

    public void saveToDb() throws SQLException {
        String sql = String.format(
                "INSERT INTO car (location_id, brand_id, type_id, status_id, km, price) VALUES (%d, %d, %d, %d, %d, %f)",
                locationId, brandId, typeId, statusId, km, price);
        Db.update(sql);
    }

    public void updateInDb() throws SQLException {
        String sql = String.format(
                "UPDATE car SET location_id = %d, brand_id = %d, type_id = %d, status_id = %d, km = %d, price = %f WHERE id=%d",
                locationId, brandId, typeId, statusId, km, price, id);
        Db.update(sql);
    }
}