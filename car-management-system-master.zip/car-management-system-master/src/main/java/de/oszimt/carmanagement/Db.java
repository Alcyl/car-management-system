package de.oszimt.carmanagement;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class Db {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/carDB?serverTimezone=UTC";
    static final String CREATE_DB_URL = "jdbc:mysql://localhost?serverTimezone=UTC";

    static final String USER = "root";
    static final String PASS = "katzen";

    static void createDatabase() throws SQLException {
        Connection conn = DriverManager.getConnection(CREATE_DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();

        String sql = "CREATE DATABASE IF NOT EXISTS carDB;";
        stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
    }

    static ArrayList<HashMap<String, Object>> query(String sql) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();

        ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

        ResultSet rs = stmt.executeQuery(sql);
        ResultSetMetaData md = rs.getMetaData();
        int columns = md.getColumnCount();
        while (rs.next()) {
            HashMap<String, Object> row = new HashMap<String, Object>(columns);
            for (int i = 1; i <= columns; ++i) {
                row.put(md.getColumnName(i), rs.getObject(i));
            }
            list.add(row);
        }

        stmt.close();
        conn.close();
        return list;
    }

    static int update(String sql) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
        ResultSet rs = stmt.getGeneratedKeys();
        int id = 0;
        if (rs.next()) {
            id = rs.getInt(1);
        }
        stmt.close();
        conn.close();
        return id;
    }

    static int addName(String table, String name) throws SQLException {
        try {
            String sql = String.format("INSERT INTO %s (name) VALUES ('%s')", table, name);
            return update(sql);
        } catch (SQLException e) {
            return getIdFromName(table, name);
        }
    }

    static String getName(String table, int id) throws SQLException {
        String sql = String.format("SELECT name FROM %s WHERE id=%d", table, id);
        return (String) query(sql).get(0).get("name");
    }

    static int getIdFromName(String table, String name) throws SQLException {
        String sql = String.format("SELECT id FROM %s WHERE name='%s'", table, name);
        return (int) query(sql).get(0).get("id");
    }

    static void delete(String table, int id) throws SQLException {
        String sql = String.format("DELETE FROM %s WHERE id=%d", table, id);
        update(sql);
    }

    static void clear() throws SQLException {
        String sql = "DROP TABLE IF EXISTS car,brand,location,status,type,metadata";
        update(sql);
    }

    static ArrayList<Car> getAllCars() throws SQLException {
        ArrayList<Car> cars = new ArrayList<Car>();
        String sql = "SELECT * FROM car";
        ArrayList<HashMap<String, Object>> maps = query(sql);
        for (HashMap<String, Object> map : maps) {
            cars.add(new Car(map));
        }
        return cars;
    }

    static Car getCar(int id) throws SQLException {
        String sql = "SELECT * from car WHERE id=" + id;
        HashMap<String, Object> map = query(sql).get(0);
        return new Car(map);
    }

    static boolean wasXMLImported() {
        try {
            String sql = "CREATE TABLE metadata ( id int(11) );";
            update(sql);
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    static void initDatabase() throws Exception {
        createDatabase();
        String createLocationSql = new String(Files.readAllBytes(Paths.get("bin/database/create_location.sql")));
        String createBrandSql = new String(Files.readAllBytes(Paths.get("bin/database/create_brand.sql")));
        String createTypeSql = new String(Files.readAllBytes(Paths.get("bin/database/create_type.sql")));
        String createStatusSql = new String(Files.readAllBytes(Paths.get("bin/database/create_status.sql")));
        String createCarSql = new String(Files.readAllBytes(Paths.get("bin/database/create_car.sql")));
        update(createLocationSql);
        update(createBrandSql);
        update(createTypeSql);
        update(createStatusSql);
        update(createCarSql);
    }

}