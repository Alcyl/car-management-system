package de.oszimt.carmanagement;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class App {

    static void show(String table) throws SQLException {
        String sql = "SELECT * FROM " + table;
        ArrayList<HashMap<String, Object>> vars = Db.query(sql);

        for (HashMap<String, Object> v : vars) {
            System.out.println(String.format("%d: %s", v.get("id"), v.get("name")));
        }
    }

    static void showAllCars() throws SQLException {
        ArrayList<Car> cars = Db.getAllCars();
        for (Car car : cars) {
            System.out.println(car.toString());
        }
    }

    static void addCarPartPrompt(String table, String extra) {
        System.out.println(String.format("Type in the id of the %s %s", table, extra));
    }

    static void addPrompt(String table) {
        System.out.println("Type in your " + table);
    }

    static void addXml() throws Exception {
        File f = new File("bin/database/carDB.xml");
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        Document document = documentBuilder.parse(f);

        NodeList carTags = document.getElementsByTagName("car");

        for (int i = 0; i < carTags.getLength(); i++) {
            NodeList carTag = carTags.item(i).getChildNodes();

            int location_id = Db.addName("location", carTag.item(1).getTextContent());
            int brand_id = Db.addName("brand", carTag.item(3).getTextContent());
            int type_id = Db.addName("type", carTag.item(5).getTextContent());
            int status_id = Db.addName("status", carTag.item(7).getTextContent());
            double price = Double.parseDouble(carTag.item(9).getTextContent());
            int km = Integer.parseInt(carTag.item(11).getTextContent());

            Car car = new Car(location_id, brand_id, type_id, status_id, km, price);
            car.saveToDb();
        }
    }

    static int getId(Scanner in, String table) throws SQLException {
        addCarPartPrompt(table, "");
        show(table);
        System.out.println("-1: CANCEL");
        return in.nextInt();
    }

    static void updateCar(Scanner in) throws SQLException {
        addCarPartPrompt("car", "you want to edit");
        showAllCars();
        int carId = in.nextInt();
        Car c = Db.getCar(carId);
        System.out.println("You have selected:\n" + c.toString() + "\n");

        while (true) {
            System.out.println("Which detail do you want to edit?");
            System.out.println(
                    "Location (1)\nBrand (2)\nType (3)\nStatus (4)\nKilometers (5)\nPrice (6)\nDisplay new Car (7)\nUpdate Car (8)\nCANCEL (0)\n");
            switch (in.nextInt()) {
            case 0: {
                return;
            }
            case 1:
                c.locationId = getId(in, "location");
                break;
            case 2:
                c.brandId = getId(in, "brand");
                break;
            case 3:
                c.typeId = getId(in, "type");
                break;
            case 4:
                c.statusId = getId(in, "status");
                break;
            case 5:
                System.out.println("Enter kilometers");
                c.km = in.nextInt();
                break;
            case 6:
                System.out.println("Enter Price");
                c.price = in.nextDouble();
            case 7:
                c.getNamesFromDb();
                System.out.println(c.toString());
            case 8:
                c.updateInDb();
                System.out.println("Car Updated");
                return;
            }
        }
    }

    static void addCar(Scanner in) throws SQLException {
        System.out.println("Add car");
        int locationId = getId(in, "location");
        if (locationId == -1) {
            return;
        }
        int brandId = getId(in, "brand");
        if (brandId == -1) {
            return;
        }
        int statusId = getId(in, "status");
        if (statusId == -1) {
            return;
        }
        int typeId = getId(in, "type");
        if (typeId == -1) {
            return;
        }

        System.out.println("Enter kilometers (-1) to CANCEL");
        int km = in.nextInt();
        if (km == -1) {
            return;
        }
        System.out.println("Enter Price (-1) to CANCEL");
        double price = in.nextDouble();
        if (price == -1) {
            return;
        }

        Car car = new Car(locationId, brandId, typeId, statusId, km, price);
        car.saveToDb();

    }

    public static void main(String[] args) {
        try {
            Db.initDatabase();
            if (!Db.wasXMLImported()) {
                addXml();
            }
            String[] options = new String[] { "Show all locations", "Show all Cars", "Add new car to the system",
                    "Add new car brand to the system", "Add new car location to the system",
                    "Add new car type to the system", "Add new car status to the system", "Change car details",
                    "Delete a car from the system" };

            String intro = "---Car Management System---\n\n" + "Choose what to do by entering a number\n\n";

            for (int i = 0; i < options.length; i++) {
                intro += String.format(options[i] + " (%d)\n", i + 1);
            }
            intro += "EXIT (-1)\n";

            Scanner in = new Scanner(System.in);
            while (true) {
                System.out.println(intro);
                int choice = in.nextInt();

                switch (choice) {
                case -1:
                    in.close();
                    return;
                case 1:
                    show("location");
                    break;
                case 2:
                    showAllCars();
                    break;
                case 3:
                    addCar(in);
                    break;
                case 4:
                    addPrompt("brand");
                    in.nextLine();
                    Db.addName("brand", in.nextLine());
                    break;
                case 5:
                    addPrompt("location");
                    in.nextLine();
                    Db.addName("location", in.nextLine());
                    break;
                case 6:
                    addPrompt("type");
                    in.nextLine();
                    Db.addName("type", in.nextLine());
                    break;
                case 7:
                    addPrompt("status");
                    in.nextLine();
                    Db.addName("status", in.nextLine());
                    break;
                case 8:
                    updateCar(in);
                    break;
                case 9:
                    addCarPartPrompt("car", "you want to delete");
                    showAllCars();
                    int carId = in.nextInt();
                    Db.delete("car", carId);
                }
            }
        } catch (Exception e) {
            System.out.println("Exception:\n " + e.toString());
        }
    }
}
